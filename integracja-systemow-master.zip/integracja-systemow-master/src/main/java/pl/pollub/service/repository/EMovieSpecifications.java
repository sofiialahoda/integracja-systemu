package pl.pollub.service.repository;

public enum EMovieSpecifications {
    HAS_AWARDS,
    HAS_POSTER,
    HAS_GENRE,
    HAS_DIRECTOR,
    HAS_WRITER,
    HAS_LANGUAGE,
    HAS_COUNTRY,
    HAS_YEAR,
    HAS_TITLE,
    HAS_ACTORS,
    ALL
}
